const { ethers } = require("hardhat");

async function main() {
  const [signer] = await ethers.getSigners();
  const contractAddresses = [
    "0x008a03e7c8f141a911d72d2f00184d4d32b0bcd1",
    "0x493aa7d45e6cc0ad3a7f0205c037eafe2b7bd87a"
  ];

  for (const address of contractAddresses) {
    console.log(`Testing contract at ${address}`);
    const MusicNFT = await ethers.getContractFactory("MusicNFT");
    const contract = MusicNFT.attach(address);

    try {
      const owner = await contract.owner();
      console.log(`Owner: ${owner}`);
      const tokenCount = await contract.getTokenCount();
      console.log(`Token Count: ${tokenCount.toString()}`);
    } catch (error) {
      console.error(`Error testing ${address}: ${error.message}`);
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});


