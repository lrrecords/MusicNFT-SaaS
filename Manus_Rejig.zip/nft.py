from flask import Blueprint, request, jsonify
from web3 import Web3
import json
import os

nft_bp = Blueprint('nft', __name__)

# Contract configuration
CONTRACT_ADDRESS = "0x1c6D8D2C85d65b20413532a2b464b59f0CEA07d8"
RPC_URL = "https://rpc-amoy.polygon.technology"
PRIVATE_KEY = "859dc54029622dddf890051c1a32256ea6badb9613a3a81803e05c344636d9b5"

# Contract ABI (simplified for our needs)
CONTRACT_ABI = [
    {
        "inputs": [{"internalType": "address", "name": "to", "type": "address"}],
        "name": "mint",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getTokenCount",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [{"internalType": "uint256", "name": "tokenId", "type": "uint256"}],
        "name": "ownerOf",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
    }
]

# Initialize Web3
w3 = Web3(Web3.HTTPProvider(RPC_URL))
contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=CONTRACT_ABI)

@nft_bp.route('/contract-info', methods=['GET'])
def get_contract_info():
    """Get basic contract information"""
    try:
        token_count = contract.functions.getTokenCount().call()
        owner = contract.functions.owner().call()
        
        return jsonify({
            'success': True,
            'data': {
                'contract_address': CONTRACT_ADDRESS,
                'total_tokens': token_count,
                'owner': owner,
                'network': 'Polygon Amoy Testnet'
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@nft_bp.route('/mint', methods=['POST'])
def mint_nft():
    """Mint a new NFT"""
    try:
        data = request.get_json()
        recipient_address = data.get('recipient_address')
        
        if not recipient_address:
            return jsonify({'success': False, 'error': 'Recipient address is required'}), 400
        
        # Validate address
        if not w3.is_address(recipient_address):
            return jsonify({'success': False, 'error': 'Invalid recipient address'}), 400
        
        # Get account from private key
        account = w3.eth.account.from_key(PRIVATE_KEY)
        
        # Build transaction
        transaction = contract.functions.mint(recipient_address).build_transaction({
            'from': account.address,
            'gas': 200000,
            'gasPrice': w3.to_wei('20', 'gwei'),
            'nonce': w3.eth.get_transaction_count(account.address),
        })
        
        # Sign and send transaction
        signed_txn = w3.eth.account.sign_transaction(transaction, PRIVATE_KEY)
        tx_hash = w3.eth.send_raw_transaction(signed_txn.rawTransaction)
        
        # Wait for transaction receipt
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        
        return jsonify({
            'success': True,
            'data': {
                'transaction_hash': receipt.transactionHash.hex(),
                'token_id': receipt.logs[0]['topics'][3].hex() if receipt.logs else None,
                'recipient': recipient_address
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@nft_bp.route('/tokens', methods=['GET'])
def get_tokens():
    """Get list of all tokens"""
    try:
        token_count = contract.functions.getTokenCount().call()
        tokens = []
        
        for token_id in range(1, token_count + 1):
            try:
                owner = contract.functions.ownerOf(token_id).call()
                tokens.append({
                    'token_id': token_id,
                    'owner': owner
                })
            except:
                # Token might not exist or be burned
                continue
        
        return jsonify({
            'success': True,
            'data': {
                'total_count': token_count,
                'tokens': tokens
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@nft_bp.route('/user-tokens/<address>', methods=['GET'])
def get_user_tokens(address):
    """Get tokens owned by a specific address"""
    try:
        if not w3.is_address(address):
            return jsonify({'success': False, 'error': 'Invalid address'}), 400
        
        token_count = contract.functions.getTokenCount().call()
        user_tokens = []
        
        for token_id in range(1, token_count + 1):
            try:
                owner = contract.functions.ownerOf(token_id).call()
                if owner.lower() == address.lower():
                    user_tokens.append({
                        'token_id': token_id,
                        'owner': owner
                    })
            except:
                continue
        
        return jsonify({
            'success': True,
            'data': {
                'address': address,
                'tokens': user_tokens,
                'count': len(user_tokens)
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

