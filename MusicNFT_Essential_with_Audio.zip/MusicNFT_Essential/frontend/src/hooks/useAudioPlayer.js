import { useState, useCallback } from 'react'

const useAudioPlayer = (tracks = []) => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [playlist, setPlaylist] = useState(tracks)

  const currentTrack = playlist[currentTrackIndex] || null

  const play = useCallback(() => {
    setIsPlaying(true)
  }, [])

  const pause = useCallback(() => {
    setIsPlaying(false)
  }, [])

  const togglePlayPause = useCallback(() => {
    setIsPlaying(prev => !prev)
  }, [])

  const next = useCallback(() => {
    if (currentTrackIndex < playlist.length - 1) {
      setCurrentTrackIndex(prev => prev + 1)
    } else {
      setCurrentTrackIndex(0) // Loop back to first track
    }
  }, [currentTrackIndex, playlist.length])

  const previous = useCallback(() => {
    if (currentTrackIndex > 0) {
      setCurrentTrackIndex(prev => prev - 1)
    } else {
      setCurrentTrackIndex(playlist.length - 1) // Loop to last track
    }
  }, [currentTrackIndex, playlist.length])

  const selectTrack = useCallback((index) => {
    if (index >= 0 && index < playlist.length) {
      setCurrentTrackIndex(index)
      setIsPlaying(true)
    }
  }, [playlist.length])

  const updatePlaylist = useCallback((newTracks) => {
    setPlaylist(newTracks)
    if (currentTrackIndex >= newTracks.length) {
      setCurrentTrackIndex(0)
    }
  }, [currentTrackIndex])

  const addToPlaylist = useCallback((track) => {
    setPlaylist(prev => [...prev, track])
  }, [])

  const removeFromPlaylist = useCallback((index) => {
    setPlaylist(prev => prev.filter((_, i) => i !== index))
    if (index === currentTrackIndex && index >= playlist.length - 1) {
      setCurrentTrackIndex(Math.max(0, playlist.length - 2))
    } else if (index < currentTrackIndex) {
      setCurrentTrackIndex(prev => prev - 1)
    }
  }, [currentTrackIndex, playlist.length])

  return {
    // State
    currentTrack,
    currentTrackIndex,
    isPlaying,
    playlist,
    
    // Actions
    play,
    pause,
    togglePlayPause,
    next,
    previous,
    selectTrack,
    updatePlaylist,
    addToPlaylist,
    removeFromPlaylist
  }
}

export default useAudioPlayer

