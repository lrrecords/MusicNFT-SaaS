import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  SkipBack, 
  SkipForward,
  Music,
  Download,
  Heart,
  Share2
} from 'lucide-react'

const AudioPlayer = ({ 
  track, 
  isPlaying, 
  onPlayPause, 
  onNext, 
  onPrevious,
  showControls = true,
  compact = false 
}) => {
  const audioRef = useRef(null)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Format time in MM:SS
  const formatTime = (time) => {
    if (isNaN(time)) return '0:00'
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, '0')}`
  }

  // Handle audio events
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleLoadedMetadata = () => {
      setDuration(audio.duration)
      setIsLoading(false)
    }

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime)
    }

    const handleLoadStart = () => {
      setIsLoading(true)
    }

    const handleCanPlay = () => {
      setIsLoading(false)
    }

    audio.addEventListener('loadedmetadata', handleLoadedMetadata)
    audio.addEventListener('timeupdate', handleTimeUpdate)
    audio.addEventListener('loadstart', handleLoadStart)
    audio.addEventListener('canplay', handleCanPlay)

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata)
      audio.removeEventListener('timeupdate', handleTimeUpdate)
      audio.removeEventListener('loadstart', handleLoadStart)
      audio.removeEventListener('canplay', handleCanPlay)
    }
  }, [track])

  // Handle play/pause
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    if (isPlaying) {
      audio.play().catch(console.error)
    } else {
      audio.pause()
    }
  }, [isPlaying])

  // Handle volume changes
  useEffect(() => {
    const audio = audioRef.current
    if (audio) {
      audio.volume = isMuted ? 0 : volume
    }
  }, [volume, isMuted])

  const handleSeek = (value) => {
    const audio = audioRef.current
    if (audio) {
      const newTime = (value[0] / 100) * duration
      audio.currentTime = newTime
      setCurrentTime(newTime)
    }
  }

  const handleVolumeChange = (value) => {
    setVolume(value[0] / 100)
    setIsMuted(false)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  if (!track) {
    return (
      <Card className="bg-gray-900/50 border-gray-700">
        <CardContent className="p-6 text-center">
          <Music className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">No track selected</p>
        </CardContent>
      </Card>
    )
  }

  if (compact) {
    return (
      <div className="flex items-center gap-3 bg-gray-900/50 rounded-lg p-3 border border-gray-700">
        <audio ref={audioRef} src={track.audioUrl} />
        
        <Button
          size="sm"
          onClick={onPlayPause}
          disabled={isLoading}
          className="bg-gradient-to-r from-teal-500 to-yellow-500 hover:from-teal-600 hover:to-yellow-600 text-black"
        >
          {isLoading ? (
            <div className="spinner w-4 h-4" />
          ) : isPlaying ? (
            <Pause className="w-4 h-4" />
          ) : (
            <Play className="w-4 h-4" />
          )}
        </Button>

        <div className="flex-1 min-w-0">
          <p className="text-white text-sm font-medium truncate">{track.title}</p>
          <p className="text-gray-400 text-xs truncate">{track.artist}</p>
        </div>

        <div className="text-xs text-gray-400">
          {formatTime(currentTime)} / {formatTime(duration)}
        </div>
      </div>
    )
  }

  return (
    <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm">
      <CardContent className="p-6">
        <audio ref={audioRef} src={track.audioUrl} />
        
        {/* Track Info */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-yellow-400 rounded-lg flex items-center justify-center">
            {track.artwork ? (
              <img 
                src={track.artwork} 
                alt={track.title}
                className="w-full h-full object-cover rounded-lg"
              />
            ) : (
              <Music className="w-8 h-8 text-black" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="text-white font-semibold text-lg truncate">
              {track.title || `Token #${track.tokenId}`}
            </h3>
            <p className="text-gray-400 truncate">
              {track.artist || `Owner: ${track.owner?.slice(0, 6)}...${track.owner?.slice(-4)}`}
            </p>
            <p className="text-teal-400 text-sm">
              NFT #{track.tokenId}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white">
              <Heart className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white">
              <Share2 className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white">
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-4">
          <Slider
            value={[duration ? (currentTime / duration) * 100 : 0]}
            onValueChange={handleSeek}
            max={100}
            step={0.1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Controls */}
        {showControls && (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={onPrevious}
                className="border-gray-600 text-gray-400 hover:text-white"
              >
                <SkipBack className="w-4 h-4" />
              </Button>
              
              <Button
                onClick={onPlayPause}
                disabled={isLoading}
                className="bg-gradient-to-r from-teal-500 to-yellow-500 hover:from-teal-600 hover:to-yellow-600 text-black w-12 h-12 rounded-full"
              >
                {isLoading ? (
                  <div className="spinner w-5 h-5" />
                ) : isPlaying ? (
                  <Pause className="w-5 h-5" />
                ) : (
                  <Play className="w-5 h-5" />
                )}
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                onClick={onNext}
                className="border-gray-600 text-gray-400 hover:text-white"
              >
                <SkipForward className="w-4 h-4" />
              </Button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleMute}
                className="text-gray-400 hover:text-white"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </Button>
              
              <Slider
                value={[isMuted ? 0 : volume * 100]}
                onValueChange={handleVolumeChange}
                max={100}
                step={1}
                className="w-20"
              />
            </div>
          </div>
        )}

        {/* Waveform Visualization */}
        <div className="flex items-center justify-center gap-1 mt-4 h-8">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className={`waveform-bar ${isPlaying ? 'animate-pulse' : ''}`}
              style={{
                animationDelay: `${i * 0.1}s`,
                height: isPlaying ? `${Math.random() * 100 + 20}%` : '20%'
              }}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export default AudioPlayer

