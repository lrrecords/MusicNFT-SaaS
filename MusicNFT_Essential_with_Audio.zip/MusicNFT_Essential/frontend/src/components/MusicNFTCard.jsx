import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Play, 
  Pause, 
  Music, 
  ExternalLink, 
  Download,
  Heart,
  Share2,
  Eye
} from 'lucide-react'

const MusicNFTCard = ({ 
  token, 
  isPlaying, 
  onPlayPause, 
  onSelect,
  showAudioPreview = true 
}) => {
  const [isHovered, setIsHovered] = useState(false)
  const [isLiked, setIsLiked] = useState(false)

  // Mock data for demonstration - in real app, this would come from IPFS/metadata
  const mockTrackData = {
    title: token.metadata?.title || `Untitled Track #${token.token_id}`,
    artist: token.metadata?.artist || `Artist ${token.owner.slice(0, 6)}`,
    genre: token.metadata?.genre || 'Electronic',
    duration: token.metadata?.duration || '3:42',
    audioUrl: token.metadata?.audioUrl || `https://www.soundjay.com/misc/sounds/bell-ringing-05.wav`, // Demo audio
    artwork: token.metadata?.artwork || null,
    description: token.metadata?.description || 'A unique music NFT created on the blockchain.',
    releaseDate: token.metadata?.releaseDate || '2025',
    bpm: token.metadata?.bpm || '128'
  }

  const handlePlayPause = (e) => {
    e.stopPropagation()
    onPlayPause(token.token_id, mockTrackData)
  }

  const handleCardClick = () => {
    onSelect && onSelect(token, mockTrackData)
  }

  const handleLike = (e) => {
    e.stopPropagation()
    setIsLiked(!isLiked)
  }

  const handleShare = (e) => {
    e.stopPropagation()
    // Implement share functionality
    navigator.share?.({
      title: mockTrackData.title,
      text: `Check out this music NFT: ${mockTrackData.title} by ${mockTrackData.artist}`,
      url: window.location.href
    }).catch(console.error)
  }

  const handleViewOnExplorer = (e) => {
    e.stopPropagation()
    window.open(`https://amoy.polygonscan.com/token/0x1c6D8D2C85d65b20413532a2b464b59f0CEA07d8?a=${token.token_id}`, '_blank')
  }

  return (
    <Card 
      className="bg-gray-800/50 border-gray-700 hover:border-teal-500/50 transition-all duration-300 cursor-pointer card-hover group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleCardClick}
    >
      <CardContent className="p-0">
        {/* Artwork/Visual */}
        <div className="relative aspect-square bg-gradient-to-br from-teal-400/20 to-yellow-400/20 rounded-t-lg overflow-hidden">
          {mockTrackData.artwork ? (
            <img 
              src={mockTrackData.artwork} 
              alt={mockTrackData.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Music className="w-16 h-16 text-teal-400/50" />
            </div>
          )}
          
          {/* Overlay Controls */}
          <div className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity duration-300 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}>
            {showAudioPreview && (
              <Button
                size="lg"
                onClick={handlePlayPause}
                className="bg-gradient-to-r from-teal-500 to-yellow-500 hover:from-teal-600 hover:to-yellow-600 text-black rounded-full w-16 h-16 shadow-lg"
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6 ml-1" />
                )}
              </Button>
            )}
          </div>

          {/* Top Right Actions */}
          <div className={`absolute top-3 right-3 flex gap-2 transition-opacity duration-300 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}>
            <Button
              size="sm"
              variant="secondary"
              onClick={handleLike}
              className={`rounded-full w-8 h-8 p-0 ${
                isLiked ? 'bg-red-500 hover:bg-red-600' : 'bg-black/50 hover:bg-black/70'
              }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-white' : ''}`} />
            </Button>
          </div>

          {/* Genre Badge */}
          <div className="absolute top-3 left-3">
            <Badge variant="secondary" className="bg-black/50 text-white border-none">
              {mockTrackData.genre}
            </Badge>
          </div>

          {/* Duration */}
          <div className="absolute bottom-3 right-3">
            <Badge variant="outline" className="bg-black/50 text-white border-gray-600">
              {mockTrackData.duration}
            </Badge>
          </div>
        </div>

        {/* Track Info */}
        <div className="p-4">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-semibold text-lg truncate">
                {mockTrackData.title}
              </h3>
              <p className="text-gray-400 truncate">
                {mockTrackData.artist}
              </p>
            </div>
            <Badge variant="outline" className="border-teal-500 text-teal-400 ml-2">
              #{token.token_id}
            </Badge>
          </div>

          {/* Track Details */}
          <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
            <span>{mockTrackData.releaseDate}</span>
            <span>•</span>
            <span>{mockTrackData.bpm} BPM</span>
          </div>

          {/* Owner Info */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-xs text-gray-500">Owner</p>
              <p className="text-sm font-mono text-white">
                {token.owner.slice(0, 6)}...{token.owner.slice(-4)}
              </p>
            </div>
            
            {/* Playing Indicator */}
            {isPlaying && (
              <div className="flex items-center gap-1">
                <div className="music-visualizer">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="music-bar" />
                  ))}
                </div>
                <span className="text-xs text-teal-400 ml-2">Playing</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              variant="outline" 
              onClick={handleShare}
              className="flex-1 border-gray-600 text-gray-400 hover:text-white hover:border-teal-500"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={handleViewOnExplorer}
              className="border-gray-600 text-gray-400 hover:text-white hover:border-yellow-500"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default MusicNFTCard

