import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Music, Wallet, Users, TrendingUp, Play, Pause, Volume2 } from 'lucide-react'
import AudioPlayer from './components/AudioPlayer.jsx'
import MusicNFTCard from './components/MusicNFTCard.jsx'
import useAudioPlayer from './hooks/useAudioPlayer.js'
import './App.css'

function App() {
  const [contractInfo, setContractInfo] = useState(null)
  const [tokens, setTokens] = useState([])
  const [mintAddress, setMintAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [userTokens, setUserTokens] = useState([])
  const [searchAddress, setSearchAddress] = useState('')
  const [selectedTrack, setSelectedTrack] = useState(null)

  // Audio player state
  const {
    currentTrack,
    isPlaying,
    togglePlayPause,
    next,
    previous,
    selectTrack,
    updatePlaylist
  } = useAudioPlayer([])

  // Fetch contract information
  const fetchContractInfo = async () => {
    try {
      const response = await fetch('/api/nft/contract-info')
      const data = await response.json()
      if (data.success) {
        setContractInfo(data.data)
      }
    } catch (error) {
      console.error('Error fetching contract info:', error)
    }
  }

  // Fetch all tokens
  const fetchTokens = async () => {
    try {
      const response = await fetch('/api/nft/tokens')
      const data = await response.json()
      if (data.success) {
        setTokens(data.data.tokens)
        
        // Create mock playlist for demo
        const mockPlaylist = data.data.tokens.map(token => ({
          tokenId: token.token_id,
          title: `Track #${token.token_id}`,
          artist: `Artist ${token.owner.slice(0, 6)}`,
          audioUrl: `https://www.soundjay.com/misc/sounds/bell-ringing-05.wav`, // Demo audio
          owner: token.owner
        }))
        updatePlaylist(mockPlaylist)
      }
    } catch (error) {
      console.error('Error fetching tokens:', error)
    }
  }

  // Mint new NFT
  const handleMint = async () => {
    if (!mintAddress) return
    
    setLoading(true)
    try {
      const response = await fetch('/api/nft/mint', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recipient_address: mintAddress
        })
      })
      
      const data = await response.json()
      if (data.success) {
        alert(`NFT minted successfully! Transaction: ${data.data.transaction_hash}`)
        setMintAddress('')
        fetchContractInfo()
        fetchTokens()
      } else {
        alert(`Error: ${data.error}`)
      }
    } catch (error) {
      alert(`Error: ${error.message}`)
    }
    setLoading(false)
  }

  // Search user tokens
  const handleSearchUserTokens = async () => {
    if (!searchAddress) return
    
    try {
      const response = await fetch(`/api/nft/user-tokens/${searchAddress}`)
      const data = await response.json()
      if (data.success) {
        setUserTokens(data.data.tokens)
      }
    } catch (error) {
      console.error('Error fetching user tokens:', error)
    }
  }

  // Handle track selection from NFT card
  const handleTrackSelect = (token, trackData) => {
    setSelectedTrack(trackData)
    const trackIndex = tokens.findIndex(t => t.token_id === token.token_id)
    if (trackIndex !== -1) {
      selectTrack(trackIndex)
    }
  }

  // Handle play/pause from NFT card
  const handleCardPlayPause = (tokenId, trackData) => {
    const trackIndex = tokens.findIndex(t => t.token_id === tokenId)
    if (trackIndex !== -1) {
      if (currentTrack && currentTrack.tokenId === tokenId) {
        togglePlayPause()
      } else {
        setSelectedTrack(trackData)
        selectTrack(trackIndex)
      }
    }
  }

  useEffect(() => {
    fetchContractInfo()
    fetchTokens()
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Header */}
      <header className="border-b border-teal-500/20 bg-black/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-teal-400 to-gold-400 rounded-lg flex items-center justify-center">
                <Music className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">LR Records</h1>
                <p className="text-teal-400 text-sm">Music NFT Platform</p>
              </div>
            </div>
            <Badge variant="outline" className="border-teal-500 text-teal-400">
              Polygon Amoy
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Mint Your Music as
            <span className="bg-gradient-to-r from-teal-400 to-yellow-400 bg-clip-text text-transparent"> NFTs</span>
          </h2>
          <p className="text-gray-300 text-lg md:text-xl max-w-2xl mx-auto">
            Transform your music into unique digital assets. Connect with fans, create exclusive content, and build your digital legacy.
          </p>
        </div>

        {/* Audio Player */}
        {(currentTrack || selectedTrack) && (
          <div className="mb-12">
            <AudioPlayer
              track={selectedTrack || currentTrack}
              isPlaying={isPlaying}
              onPlayPause={togglePlayPause}
              onNext={next}
              onPrevious={previous}
            />
          </div>
        )}

        {/* Stats Cards */}
        {contractInfo && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Total NFTs Minted</CardTitle>
                <Music className="h-4 w-4 text-teal-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{contractInfo.total_tokens}</div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Contract Owner</CardTitle>
                <Wallet className="h-4 w-4 text-yellow-400" />
              </CardHeader>
              <CardContent>
                <div className="text-sm font-mono text-white">
                  {contractInfo.owner.slice(0, 6)}...{contractInfo.owner.slice(-4)}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Network</CardTitle>
                <TrendingUp className="h-4 w-4 text-teal-400" />
              </CardHeader>
              <CardContent>
                <div className="text-sm text-white">{contractInfo.network}</div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Mint Section */}
        <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm mb-12">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Music className="w-5 h-5 text-teal-400" />
              Mint New Music NFT
            </CardTitle>
            <CardDescription className="text-gray-300">
              Create a new NFT for your music. Enter the recipient wallet address below.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Input
                placeholder="Recipient wallet address (0x...)"
                value={mintAddress}
                onChange={(e) => setMintAddress(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
              <Button 
                onClick={handleMint}
                disabled={loading || !mintAddress}
                className="bg-gradient-to-r from-teal-500 to-yellow-500 hover:from-teal-600 hover:to-yellow-600 text-black font-semibold"
              >
                {loading ? 'Minting...' : 'Mint NFT'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search User Tokens */}
        <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm mb-12">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-yellow-400" />
              Search User Collection
            </CardTitle>
            <CardDescription className="text-gray-300">
              Find all NFTs owned by a specific wallet address.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Input
                placeholder="Search wallet address (0x...)"
                value={searchAddress}
                onChange={(e) => setSearchAddress(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
              <Button 
                onClick={handleSearchUserTokens}
                disabled={!searchAddress}
                variant="outline"
                className="border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-black"
              >
                Search
              </Button>
            </div>
            
            {userTokens.length > 0 && (
              <div className="mt-6">
                <h3 className="text-white font-semibold mb-4">Found {userTokens.length} NFT(s)</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {userTokens.map((token) => (
                    <MusicNFTCard
                      key={token.token_id}
                      token={token}
                      isPlaying={currentTrack?.tokenId === token.token_id && isPlaying}
                      onPlayPause={handleCardPlayPause}
                      onSelect={handleTrackSelect}
                    />
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* All Tokens */}
        <Card className="bg-gray-900/50 border-teal-500/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Volume2 className="w-5 h-5 text-yellow-400" />
              All Music NFTs
            </CardTitle>
            <CardDescription className="text-gray-300">
              Browse all minted music NFTs on the platform. Click to listen!
            </CardDescription>
          </CardHeader>
          <CardContent>
            {tokens.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tokens.map((token) => (
                  <MusicNFTCard
                    key={token.token_id}
                    token={token}
                    isPlaying={currentTrack?.tokenId === token.token_id && isPlaying}
                    onPlayPause={handleCardPlayPause}
                    onSelect={handleTrackSelect}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Music className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">No NFTs minted yet. Be the first to create one!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <footer className="border-t border-teal-500/20 bg-black/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p className="text-gray-400">
              © 2025 LR Records. Powered by Polygon Amoy Testnet.
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Contract: {contractInfo?.contract_address}
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

